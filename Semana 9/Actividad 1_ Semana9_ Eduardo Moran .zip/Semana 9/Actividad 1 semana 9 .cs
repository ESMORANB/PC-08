﻿using System;

class actividad_1
{
    static void Main(string[] args)
    {
        int numero;
        string entrada;

        while (true)
        {
            Console.WriteLine("Ingrese un número (hasta 6 cifras):");
            entrada = Console.ReadLine();

            if (int.TryParse(entrada, out numero) && entrada.Length <= 6) // se usta variable.Length para determinar el numero de cifras que este tendra 
            {
                break;
            }
            else
            {
                Console.WriteLine("Entrada inválida. Inténtalo de nuevo.");
            }
        }

        if (numero <= 1)
        {
            Console.WriteLine("No es un numero primo");
        }
        else if (numero == 2)
        {
            Console.WriteLine("Es un numero primo");
        }
        else
        {
            bool esPrimo = true;
            for (int i = 2; i <= Math.Sqrt(numero); i++)
            {
                if (numero % i == 0)
                {
                    esPrimo = false;
                    break; 
                }
            }
            Console.WriteLine(esPrimo ? "Es un numero primo" : "No es un numero primo");
        }
    }
}
