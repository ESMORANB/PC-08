﻿
class   ClaseSemana8
{
    static void Main()
    {
        int numero;
        string entrada;
    
        while (true)
            {
                Console.Write("Ingrese un número positivo: ");
                entrada = Console.ReadLine();

                if (int.TryParse(entrada, out numero)) 
                {
                    
                }
                else
                {
                    Console.WriteLine("Entrada inválida. Inténtalo de nuevo.");
                    
                    break;
                }
                int resultado = calcular_factorial(numero);
                Console.WriteLine(string.Format("Su factorial es {0} :) ", resultado));
                Console.ReadKey();
            }
    }

    public static int calcular_factorial(int numero)
    {
        if(numero==0)
        {
            return 1;
        }
        else
        {
            int factorial=1;
            for(int i= 1; i<= numero; i++)
            {
                factorial*= i;
            }
            return factorial;
        }
    }
}
